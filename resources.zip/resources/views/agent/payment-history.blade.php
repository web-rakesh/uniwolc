@extends('agent.layouts.layout')
@section('content')
    <section class="sub-new-awolc-bg">
        <div class="container">
            @livewire('agent.payment-history-list')
        </div>
    </section>
@endsection
