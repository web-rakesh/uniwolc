@extends('agent.layouts.layout')
@section('content')
    @livewire('agent.staff-list')
@endsection
