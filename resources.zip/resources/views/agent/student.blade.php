@extends('agent.layouts.layout')
@section('content')
    @livewire('agent.student-list')
@endsection
