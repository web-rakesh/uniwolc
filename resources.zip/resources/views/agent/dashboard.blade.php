@extends('agent.layouts.layout')
@section('content')
    Agent Dashboard
@endsection
