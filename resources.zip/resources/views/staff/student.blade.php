@extends('staff.layouts.layout')
@section('content')
    @livewire('staff.student-list')
@endsection
