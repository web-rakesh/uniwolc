@extends('university.layouts.layout')
@section('content')
    @livewire('university.program-apply-list')
@endsection
