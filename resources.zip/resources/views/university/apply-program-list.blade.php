@extends('university.layouts.layout')
@section('content')
    <section style="background-color: #eee;">
        @livewire('university.apply-program-list')

    </section>
@endsection
