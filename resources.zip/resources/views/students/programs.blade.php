@extends('students.layouts.layout')
@section('content')
    <section class="sub-new-awolc-bg">
        <div class="container">
            @livewire('student.program')


        </div>
    </section>
@endsection
