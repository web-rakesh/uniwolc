@extends('students.layouts.layout')
@section('content')
    @livewire('student.payment-history-list')
@endsection
