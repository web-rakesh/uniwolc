 <!-- plugins:js -->
 <script src="{{ asset('admin') }}/assets/vendors/js/vendor.bundle.base.js"></script>
 <!-- endinject -->
 <!-- Plugin js for this page -->
 <!-- End plugin js for this page -->
 <!-- inject:js -->
 <script src="{{ asset('admin') }}/assets/js/off-canvas.js"></script>
 <script src="{{ asset('admin') }}/assets/js/hoverable-collapse.js"></script>
 {{-- <script src="{{ asset('admin') }}/assets/js/misc.js"></script> --}}
 <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
 <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
 <script>
     setTimeout(function() {
         $('.alert').fadeOut('slow');
     }, 4000);
 </script>
 <!-- endinject -->
