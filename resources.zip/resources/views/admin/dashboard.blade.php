@extends('admin.layouts.layout')
@section('content')
   
@endsection
