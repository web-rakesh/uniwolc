@extends('website.layouts.layout')
@section('content')
    @livewire('student.program')
@endsection