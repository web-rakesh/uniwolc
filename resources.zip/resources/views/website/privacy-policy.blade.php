@extends('website.layouts.layout')
@section('content')
    privacy-policy
@endsection
