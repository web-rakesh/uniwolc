@extends('website.layouts.layout')
@section('content')
    term-conditions
@endsection
